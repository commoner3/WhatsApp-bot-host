# WhatsApp Bot Host

A panel where users sign in with Google, paste a WhatsApp session ID, and deploy their bot.
Each bot runs in its own Docker container with a RAM limit.

## Features
- Google login
- Deploy form (session ID, bot name, owner number, plan)
- My Bots: start, stop, restart, delete, renew/extend, live console
- Free plan (1 bot per user, server-wide cap) and paid plans in coins
- Buy coins with Paystack (cards and mobile money)
- Coupons for free coins
- Admin page: stats, users, coin adjustments, bots, coupons

## Folders
| Folder | What it is |
|---|---|
| `backend/` | Node.js API (Express, PostgreSQL, Docker) |
| `frontend/` | `index.html` (users) and `admin.html` (you) |
| `bot/` | Dockerfile and `start.js` for the bot image |
| `database/` | `schema.sql` (new install) and `migrate_free_plan.sql` (older databases) |

## Setup on a VPS (Ubuntu)

1. **Install** Node 18+, Docker and PostgreSQL.
2. **Database**
   ```bash
   sudo -u postgres createdb botpanel
   psql -U youruser -d botpanel -f database/schema.sql
   ```
3. **Bot image**: copy your WhatsApp bot's code into `bot/` (next to `Dockerfile` and `start.js`),
   set the real entry file name in `start.js`, then:
   ```bash
   cd bot && docker build -t my-whatsapp-bot:latest .
   ```
4. **Backend**
   ```bash
   cd backend
   cp .env.example .env     # then fill in every value
   npm install
   npm start
   ```
   Generate the encryption key with:
   `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
5. **Frontend**: set `API` (and `GOOGLE_CLIENT_ID` in `index.html`) at the top of the script
   in `frontend/index.html` and `frontend/admin.html`, then host the files (Nginx or Cloudflare Pages).
6. **Paystack**: set the webhook URL to `https://your-api-domain/api/paystack/webhook`.
7. **Admin**: put your Google email in `ADMIN_EMAILS` in `.env`, restart, and sign in once.

Use a process manager such as PM2 to keep the backend running, and put the API behind HTTPS.

## Security notes
- Never commit `.env`. It holds your keys.
- Session IDs are encrypted in the database. If you lose `SESSION_ENC_KEY`, they cannot be read.
- Use a Paystack **test** key until everything works.
- Unofficial WhatsApp bots can get users' numbers banned. Tell your users.
