// Runs before your bot. It reads SESSION_ID from the environment, writes the
// WhatsApp login file to ./session/creds.json, then starts your bot.
//
// Session ID formats differ between bots. This handles the common one:
//   optional prefix ending in "!"  +  base64 of creds.json (optionally gzipped)
// If your session ID looks different, only change decodeSession().

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');

const SESSION_DIR = path.join(__dirname, 'session');
const { SESSION_ID } = process.env;

function decodeSession(raw) {
  // Remove a prefix such as "KnightBot!" if there is one
  const encoded = raw.includes('!') ? raw.split('!').slice(1).join('!') : raw;
  let buf = Buffer.from(encoded, 'base64');
  // gzip files start with the bytes 1f 8b
  if (buf[0] === 0x1f && buf[1] === 0x8b) buf = zlib.gunzipSync(buf);
  const text = buf.toString('utf8');
  JSON.parse(text); // throws if it is not valid JSON
  return text;
}

if (!SESSION_ID) {
  console.error('SESSION_ID is missing.');
  process.exit(1);
}

try {
  fs.mkdirSync(SESSION_DIR, { recursive: true });
  const credsFile = path.join(SESSION_DIR, 'creds.json');
  // Only write on first start; later restarts keep the refreshed login
  if (!fs.existsSync(credsFile)) {
    fs.writeFileSync(credsFile, decodeSession(SESSION_ID));
  }
} catch (err) {
  console.error('Could not read SESSION_ID:', err.message);
  process.exit(1);
}

// Remove the session ID from the environment so the bot code can't log it
delete process.env.SESSION_ID;

// Start the real bot. Change "index.js" to your bot's main file.
const bot = spawn('node', ['index.js'], { stdio: 'inherit', env: process.env });
bot.on('exit', (code) => process.exit(code ?? 1));
process.on('SIGTERM', () => bot.kill('SIGTERM'));
